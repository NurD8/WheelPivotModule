#ifndef WHEELPIVOTMODULE_H
#define WHEELPIVOTMODULE_H

#include <Arduino.h>
#include <RotaryEncoder.h>

class WheelPivotModule {
public:
    WheelPivotModule(int dirPin, int stepPin, int pinIn1, int pinIn2, int hallPin);
    void begin();
    void update();
    int moveToAngle(float inputAngle);
    void homingSequence();

private:
    int motor(int setpointAngle);
    int errorCorrection(int setpointCorrection);
    float recvWithEndMarker();
    void checkPosition();

    int _dirPin;
    int _stepPin;
    int _pinIn1;
    int _pinIn2;
    int _hallPin;
    RotaryEncoder* _encoder;
    char _receivedChars[5];
};

#endif // WHEELPIVOTMODULE_H