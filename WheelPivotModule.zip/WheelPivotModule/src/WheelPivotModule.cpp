#include "WheelPivotModule.h"

WheelPivotModule* WheelPivotModule::instance = nullptr;

WheelPivotModule::WheelPivotModule(int dirPin, int stepPin, int pinIn1, int pinIn2, int hallPin) :
    _dirPin(dirPin), _stepPin(stepPin), _pinIn1(pinIn1), _pinIn2(pinIn2), _hallPin(hallPin), _encoder(nullptr) {
}

void WheelPivotModule::begin() {
    pinMode(_stepPin, OUTPUT);
    pinMode(_dirPin, OUTPUT);
    pinMode(_hallPin, INPUT);
    digitalWrite(_dirPin, HIGH);

    homingSequence();

    _encoder = new RotaryEncoder(_pinIn1, _pinIn2, RotaryEncoder::LatchMode::TWO03);
    instance = this;  // Set the instance pointer

    attachInterrupt(digitalPinToInterrupt(_pinIn1), WheelPivotModule::checkPositionISR1, CHANGE);
    attachInterrupt(digitalPinToInterrupt(_pinIn2), WheelPivotModule::checkPositionISR2, CHANGE);

    Serial.begin(115200);
    Serial.println("Wheel Pivot Module Successfully Started");
    _receivedChars[0] = '0';
}

void WheelPivotModule::update() {
    float inputAngle = recvWithEndMarker() / 0.3;
    int actualAngle;
    if (inputAngle != 0) {
        Serial.print("Input Angle: ");
        Serial.print(inputAngle * 0.3);
        actualAngle = moveToAngle(inputAngle);
        if (actualAngle != 0) {
            Serial.print(" Output Angle: ");
            Serial.println(actualAngle * 0.3);
        }
        delay(1000);
        Serial.println("");
    }
    delay(100);
}

int WheelPivotModule::moveToAngle(float inputAngle) {
    int numStep;
    long stepDelay = 2500;
    checkPosition();
    int initialAngle = _encoder->getPosition();
    digitalWrite(_dirPin, inputAngle >= 0 ? LOW : HIGH);
    int numSteps = abs(inputAngle) / 3;  // stepAngle is 3 degrees per step
    for (int i = 0; i < numSteps; i++) {
        digitalWrite(_stepPin, HIGH);
        delayMicroseconds(stepDelay);
        digitalWrite(_stepPin, LOW);
        delayMicroseconds(stepDelay);
    }

    inputAngle = fmod(inputAngle, 1200);
    checkPosition();

    int finalAngle = _encoder->getPosition();
    int angleDifference = finalAngle - initialAngle;
    int error = inputAngle - angleDifference;

    for (int i = 0; i < 10; i++) {
        if (errorCorrection(error)) {
            checkPosition();
            finalAngle = _encoder->getPosition();
            error = inputAngle - (finalAngle - initialAngle);
        } else {
            break;
        }
    }

    finalAngle = _encoder->getPosition();
    int finalPos = round(finalAngle - initialAngle);
    return finalPos;
}

int WheelPivotModule::errorCorrection(int setpointCorrection) {
    int numStep;
    long stepDelay = 2500;
    checkPosition();

    int beforeCorrection = _encoder->getPosition();
    digitalWrite(_dirPin, setpointCorrection >= 0 ? LOW : HIGH);

    int numSteps = abs(setpointCorrection) / 3;
    for (int i = 0; i < numSteps; i++) {
        digitalWrite(_stepPin, HIGH);
        delayMicroseconds(stepDelay);
        digitalWrite(_stepPin, LOW);
        delayMicroseconds(stepDelay);
    }

    setpointCorrection = fmod(setpointCorrection, 1200);
    checkPosition();

    int afterCorrection = _encoder->getPosition();
    int angleCorrection = round(afterCorrection - beforeCorrection);

    return angleCorrection;
}

void WheelPivotModule::homingSequence() {
    int sensorValue = analogRead(A0);
    int cnt = 0;
    int stepDelay = 2500;

    digitalWrite(_dirPin, HIGH);
    if (sensorValue >= 20) {
        for (int i = 0; i <= 100; i++) {
            digitalWrite(_stepPin, HIGH);
            delayMicroseconds(stepDelay);
            digitalWrite(_stepPin, LOW);
            delayMicroseconds(stepDelay);
        }
    }
    delay(100);

    digitalWrite(_dirPin, HIGH);
    while (sensorValue <= 20) {
        digitalWrite(_stepPin, HIGH);
        delayMicroseconds(stepDelay);
        digitalWrite(_stepPin, LOW);
        delayMicroseconds(stepDelay);
        sensorValue = analogRead(A0);
    }

    delay(100);

    digitalWrite(_dirPin, LOW);
    while (sensorValue > 20) {
        digitalWrite(_stepPin, HIGH);
        delayMicroseconds(stepDelay);
        digitalWrite(_stepPin, LOW);
        delayMicroseconds(stepDelay);
        sensorValue = analogRead(A0);
    }

    delay(100);
    while (sensorValue <= 20) {
        digitalWrite(_stepPin, HIGH);
        delayMicroseconds(stepDelay);
        digitalWrite(_stepPin, LOW);
        delayMicroseconds(stepDelay);
        sensorValue = analogRead(A0);
        cnt += 1;
    }

    delay(100);
    digitalWrite(_dirPin, HIGH);
    for (int i = 0; i < cnt / 2; i++) {
        digitalWrite(_stepPin, HIGH);
        delayMicroseconds(stepDelay);
        digitalWrite(_stepPin, LOW);
        delayMicroseconds(stepDelay);
    }
    sensorValue = analogRead(A0);

    if (sensorValue < 20) {
        Serial.println("Homing complete. Wheel is at zero degree position.");
    }

    if (sensorValue > 20) {
        Serial.println("Homing failed. Please restart the wheel pivot module.");
    }
}

float WheelPivotModule::recvWithEndMarker() {
    static byte ndx = 0;
    char endMarker = '\n';
    int dataNumber = 0;
    char rc;
    if (Serial.available() > 0) {
        rc = Serial.read();

        if (rc != endMarker) {
            _receivedChars[ndx] = rc;
            ndx++;
            if (ndx >= 5) {
                ndx = 5 - 1;
            }
        } else {
            _receivedChars[ndx] = '\0';
            ndx = 0;
            dataNumber = atoi(_receivedChars);
            Serial.print("Data as Number ... ");
            Serial.println(dataNumber);
            _receivedChars[0] = '0';
            return dataNumber;
        }
    }
    return 0;
}

void WheelPivotModule::checkPosition() {
    _encoder->tick();
}

void WheelPivotModule::checkPositionISR1() {
    if (instance) {
        instance->checkPosition();
    }
}

void WheelPivotModule::checkPositionISR2() {
    if (instance) {
        instance->checkPosition();
    }
}